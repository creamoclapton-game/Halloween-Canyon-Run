Run with `pip install -r requirements.txt` then `python main.py`.
